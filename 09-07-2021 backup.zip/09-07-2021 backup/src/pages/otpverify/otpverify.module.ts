import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OtpverifyPage } from './otpverify';

@NgModule({
  declarations: [
    OtpverifyPage,
  ],
  imports: [
    IonicPageModule.forChild(OtpverifyPage),
  ],
})
export class OtpverifyPageModule {}
