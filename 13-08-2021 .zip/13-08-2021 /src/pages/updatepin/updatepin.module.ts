import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdatepinPage } from './updatepin';

@NgModule({
  declarations: [
    UpdatepinPage,
  ],
  imports: [
    IonicPageModule.forChild(UpdatepinPage),
  ],
})
export class UpdatepinPageModule {}
